﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuardHealth : MonoBehaviour {

    public float Health = 15f;
    
    public void TakeDamage(float amnt)
    {
        Health -= amnt;
        if (Health <= 0)
        {
            print("Enemy is stunned!");
        }

        print("Enemy took some damage");
    }
}
