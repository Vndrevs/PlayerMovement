﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour {

    public float attackDamage;
    public float attackRange;
    public float attackCoolDown;
}
